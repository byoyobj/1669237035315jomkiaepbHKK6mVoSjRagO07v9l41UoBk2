function initAnims() {
    let timelines = {};
    let preBakedTLs = {}
    let timelineSel = document.querySelectorAll(".timelines");
    for (let i in timelineSel) {
        if (timelineSel[i].attributes?.timelines) {
            timelineSel[i].classList.add("will-change");
            let id = timelineSel[i].attributes.id.value;
            timelines[id] = [];
            preBakedTLs[id] = [];
            let tempTl = JSON.parse(timelineSel[i].attributes.timelines.value);
            for (let o in tempTl) {
                let tempEase = tempTl[o].ease;
                timelines[id][tempTl[o].label] = gsap.timeline({label:tempTl[o].label, paused: tempTl[o].paused});
                let tempKeys = JSON.parse(JSON.stringify(tempTl[o].keyframes));
                tempKeys.forEach(element => {
                    delete element.from_to;
                    delete element.ease;
                    delete element.easeDir;
                });
                let tempKeysRaw = tempTl[o].keyframes;
                if (tempTl[o].type == "custom") {
                    tempKeys.forEach(element => {
                        if (element.onStart) {
                            element.onStart = eval(element.onStart);
                        }
                    });
                    timelines[id][tempTl[o].label].to("#"+id, {keyframes: tempKeys, ease: tempEase, yoyo: false});
                    preBakedTLs[id][tempTl[o].label] = {fromTo: "to", additive: false}
                    preBakedTLs[id][tempTl[o].label].props = ["#"+id, {keyframes: tempKeys, ease: tempEase, yoyo: false}];
                }
                else if (tempTl[o].type == "basic") {
                    if (tempKeys[0].clipPath)  document.querySelector("#"+id).style.clipPath = "polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%)";
                    if (tempKeys[0].perspective)  {
                        document.querySelector("#"+id).style.transform = tempKeys[0].perspective;
                        document.querySelector("#"+id).style.transformStyle = "preserve-3d";
                    }
                    let kf1 = tempKeys[0];
                    if (tempKeys[0] && tempKeysRaw[0].from_to == "from") {
                        let toProps ={};
                        let curObj = document.querySelector("#"+id);
                        let tempTrans = "";
                        for (let h in kf1) {
                            if (h.includes("translate") || h.includes("rotate") || h.includes("scale")) {
                                let unit = h.includes("translate")? "px" : h.includes("rotate")? "deg" : ""
                                if (!toProps.transform) toProps.transform = curObj.style.transform;
                                tempTrans += h+"("+parseInt(kf1[h])+unit+") ";

                            }
                            else if (h === "autoAlpha") {
                                toProps.visibility = curObj.style.visibility || "visible";
                                toProps.opacity = curObj.style.opacity || 1;
                                curObj.style.opacity = kf1.autoAlpha* 10 /10;
                                if (toProps.autoAlpha === 0) curObj.style.visibility = "hidden";
                                else curObj.style.visibility = "visible";
                            }
                            else if (h === "filter") {
                                toProps.filter = curObj.style.filter || "blur(0px)";
                                curObj.style.filter = kf1.filter;
                            }
                            else if (h === "backdropFilter") {
                                toProps.backdropFilter = curObj.style.backdropFilter || "blur(0px)";
                                curObj.style.backdropFilter = kf1.backdropFilter;
                            }
                            else if (h === "clipPath") {
                                toProps.clipPath = curObj.style.clipPath || "polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%)";
                                curObj.style.clipPath = kf1.clipPath;
                            }
                            else if (h === "delay" || h === "duration") {
                                toProps[h] = kf1[h];
                            }
                        }
                        if (tempTrans.length > 0) curObj.style.transform = tempTrans;
                        timelines[id][tempTl[o].label].to("#"+id, {...toProps, ease: tempEase, yoyo: false});
                        preBakedTLs[id][tempTl[o].label] = {fromTo: "from", additive: true};
                        preBakedTLs[id][tempTl[o].label].props = ["#"+id, {...toProps, ease: tempEase, yoyo: false}];
                    }
                    else {
                        timelines[id][tempTl[o].label].to("#"+id, {...kf1, ease: tempEase, yoyo: false});
                        preBakedTLs[id][tempTl[o].label] = {fromTo: "to", additive: true};
                        preBakedTLs[id][tempTl[o].label].props = ["#"+id, {...kf1, ease: tempEase, yoyo: false}];
                    }
                }
                else if (tempTl[o].type == "lottie") {
                    timelines[id][tempTl[o].label].to("#"+id, {keyframes: tempKeys, ease: tempEase, yoyo: false});
                    preBakedTLs[id][tempTl[o].label] = {fromTo: "to", additive: false}
                    lottieBindGsap("#"+id,tempTl[o].link,timelines[id][tempTl[o].label]);
                }
            }
        }
    }
    function mouseMove(elem,tlX,tlY) {
        let elemyBox = elem.getBoundingClientRect();
        let elemWidth = elemyBox.width;
        let elemHeight = elemyBox.height;
        let elemLeft = elemyBox.left;
        let elemTop = elemyBox.top;
        let progWidth = gsap.utils.mapRange(elemLeft, elemWidth + elemLeft, 0, 1);
        let progHeight = gsap.utils.mapRange(elemTop, elemHeight + elemTop, 0, 1);
        elem.addEventListener("mousemove", e => {
            const x = e.pageX < (elemWidth + elemLeft) ? e.pageX : (elemWidth + elemLeft);
            const y = e.pageY < (elemHeight + elemTop) ? e.pageY : (elemHeight + elemTop);
            tlX?.progress(progWidth(x));
            tlY?.progress(progHeight(y));
        });
    }
    function lottieBindGsap(lottieElem,lottieLink,tl){
        let duration;
        let animation = bodymovin.loadAnimation({
            container: document.querySelector(lottieElem),
            renderer: 'svg',
            loop: false,
            autoplay: false,
            path: lottieLink
        });
        function checkProgress() {
            animation.goToAndStop(Math.round(tl.progress() < 0.95? tl.progress()*duration*1000 : tl.progress()*duration*1000 * 0.95));
        }
        tl.eventCallback("onUpdate", function(){
            checkProgress();
        });
        
        animation.addEventListener('config_ready',function() {
            duration = animation.getDuration();
        });
    }

    // gsap.utils.toArray(".lottie").forEach((moveObj, i) => {
        
    // });


    gsap.utils.toArray(".mouse-move").forEach((moveObj, i) => {
        
        if (moveObj.attributes) {
            let tempEvent = JSON.parse(moveObj.attributes["mouse-move"].value);
            for (let o in tempEvent) {
                tempEvent[o].trigger = tempEvent[o].trigger.split(" ").join("").split(",");
                if (tempEvent[o].trigger.length == 0) tempEvent[o].trigger = ["current"];
                tempEvent[o].trigger.forEach((trig) => {
                    let triggerElem = trig == "current" || trig == " current" ? "#"+moveObj.attributes.id.value : "#"+trig;
                    let tlObjElem = moveObj.attributes.id.value;
                    let tlLabel = tempEvent[o].tl;
                    let tlLabelY = tempEvent[o].tlY;
                    // timelines[tlObjElem][tlLabel].repeat(0);
                    document.querySelectorAll(triggerElem).forEach(element => {
                        mouseMove(element,timelines[tlObjElem][tlLabel],timelines[tlObjElem][tlLabelY]);
                    });
                });
            };
        }
    });
    gsap.registerPlugin(ScrollTrigger);

    gsap.utils.toArray(".scroll").forEach((scrollObj, i) => {
        if(scrollObj.attributes){
            if (!scrollObj.attributes.scroll) return;
            let tempEvent = JSON.parse(scrollObj.attributes.scroll.value);
            tempEvent.forEach((scrollTrig) => {
                if (scrollTrig.trigger.length == 0) {
                    scrollTrig.trigger = "current";
                }
                scrollTrig.trigger = scrollTrig.trigger.split(",");
                scrollTrig.trigger.forEach((scrollTrigTrigger) => {
                    let tempTrig ={};
                    tempTrig.scroller = scrollTrig.scroller ||  window;
                    tempTrig.animation = scrollTrig.animation || null;
                    tempTrig.trigger = scrollTrigTrigger == "current" ? "#"+scrollObj.id : "#"+scrollTrigTrigger;
                    tempTrig.start = scrollTrig.start || "top center";
                    tempTrig.end = scrollTrig.end_plus && scrollTrig.end_plus != 0? scrollTrig.end + "+="+scrollTrig.end_plus : (scrollTrig.end || "bottom top");

                    tempTrig.pin = scrollTrig.pin ? scrollObj : false;
                    tempTrig.pinSpacing = scrollTrig.pinSpacing || true;
                    tempTrig.scrub = scrollTrig.bind? (scrollTrig.scrub || true) : false;
                    tempTrig.toggleClass = scrollTrig.toggleClass || null;
                    tempTrig.toggleActions = scrollTrig.toggleActions || null;
                    tempTrig.onEnter = scrollTrig.onEnter || undefined;
                    tempTrig.onLeave = scrollTrig.onLeave || undefined;
                    tempTrig.onEnterBack = scrollTrig.onEnterBack || undefined;
                    tempTrig.onLeaveBack = scrollTrig.onLeaveBack || undefined;
                    tempTrig.onUpdate = scrollTrig.onUpdate || undefined;
                    ScrollTrigger.create({
                        trigger: tempTrig.trigger,
                        animation: timelines[scrollObj.attributes.id.value][tempTrig.animation],
                        scroller: tempTrig.scroller,
                        pin: tempTrig.pin,
                        scrub: tempTrig.scrub,
                        start: tempTrig.start,
                        end: tempTrig.end,
                        onEnter: eval(tempTrig.onEnter),
                        onLeave: eval(tempTrig.onLeave),
                        onEnterBack: eval(tempTrig.onEnterBack),
                        onLeaveBack: eval(tempTrig.onLeaveBack),
                        pinSpacing: tempTrig.pinSpacing,
                        toggleClass: tempTrig.toggleClass,
                        toggleActions: tempTrig.toggleActions,
                        onEnter: () => {eval(tempTrig.onEnter); scrollObj.classList.add("active");},
                        onLeave: () => {eval(tempTrig.onLeave); scrollObj.classList.remove("active");},
                        onEnterBack: () => {eval(tempTrig.onEnterBack); scrollObj.classList.add("active");},
                        onLeaveBack: () => {eval(tempTrig.onLeaveBack); scrollObj.classList.remove("active");},
                    });
                });
            });
        }
    });
    function eventedFunc(evented) {
        let eventName = evented == "hover"? "mouseenter" : evented;
        let curEvent = document.querySelectorAll("."+evented);
        for (let i in curEvent) {
            if (curEvent[i].attributes) {
                let tempEvent = JSON.parse(curEvent[i].attributes[evented].value);
                for (let o in tempEvent) {
                    tempEvent[o].trigger = tempEvent[o].trigger.split(" ").join("").split(",");
                    if (tempEvent[o].trigger.length == 0) tempEvent[o].trigger = ["current"];
                    tempEvent[o].trigger.forEach((trig) => {
                        let triggerElem = trig == "current" || trig == " current" ? "#"+curEvent[i].attributes.id.value : "#"+trig;
                        let tlObjElem = curEvent[i].attributes.id.value;
                        if (tempEvent[o].tlObj != "current") tlObjElem = tempEvent[o].tlObj;
                        let yoyo = false;
                        if (tempEvent[o].yoyo) yoyo = true;
                        let tlLabel = tempEvent[o].tl;
                        timelines[tlObjElem][tlLabel]?.repeat(tempEvent[o].repeat || 0);
                        timelines[tlObjElem][tlLabel]?.yoyo(tempEvent[o].yoyo);
                        document.querySelectorAll(triggerElem).forEach(element => {
                            let count = 0;
                            if ( evented == "page-load") {
                                if (tempEvent[o].reversed) {
                                    timelines[tlObjElem][tlLabel].reverse();
                                }
                                else {
                                    timelines[tlObjElem][tlLabel].play();
                                }
                                count ++;
                            }
                            else {
                                element.addEventListener(eventName, function() {
                                    if (tempEvent[o].reversed) {
                                        if (preBakedTLs[tlObjElem][tlLabel].additive && !tempEvent[o].yoyo) {
                                            // if (preBakedTLs[tlObjElem][tlLabel].fromTo == "from") {
                                            //     gsap.from(...preBakedTLs[tlObjElem][tlLabel].props, pase).reverse();
                                            // }
                                            // else {
                                            //     gsap.to(...preBakedTLs[tlObjElem][tlLabel].props).reverse();
                                            // }
                                            timelines[tlObjElem][tlLabel].reverse();
                                        }
                                        else {
                                            timelines[tlObjElem][tlLabel].reverse();
                                        }
                                    }
                                    else {
                                        if (preBakedTLs[tlObjElem][tlLabel].additive && !tempEvent[o].yoyo) {
                                            if (preBakedTLs[tlObjElem][tlLabel].fromTo == "from") {
                                                gsap.to(...preBakedTLs[tlObjElem][tlLabel].props);
                                            }
                                            else {
                                                gsap.to(...preBakedTLs[tlObjElem][tlLabel].props);
                                            }
                                            // timelines[tlObjElem][tlLabel].play();
                                        }
                                        else {
                                            timelines[tlObjElem][tlLabel].play();
                                        }
                                    }
                                    if (yoyo && count%2 == 1) {
                                        if (timelines[tlObjElem][tlLabel].reversed()) timelines[tlObjElem][tlLabel].play();
                                        else timelines[tlObjElem][tlLabel].reverse();
                                    }
                                    count ++;
                                });
                            }
                            if (evented == "hover") {
                                element.addEventListener("mouseleave", function() {
                                    if (tempEvent[o].reversed) {
                                        timelines[tlObjElem][tlLabel].play();
                                    }
                                    else {
                                        timelines[tlObjElem][tlLabel].reverse();
                                    }
                                    if (yoyo && count%2 == 1) {
                                        if (timelines[tlObjElem][tlLabel].reversed()) timelines[tlObjElem][tlLabel].reverse();
                                        else timelines[tlObjElem][tlLabel].play();
                                    }
                                    count ++;
                                });
                            }
                        });
                    });
                }
            }
        }
    }
    eventedFunc("hover");
    eventedFunc("click");
    eventedFunc("mousedown");
    eventedFunc("mouseup");
    eventedFunc("page-load");
}
initAnims();